# FOWDR

`fowdr` is a Python package for computing the dispersion relations (DRs) of the fast flavor oscillation waves in the dense neutrino gases that satisfy the following conditions. Please see `fowdr.ipynb` under `doc` for how to use this package.